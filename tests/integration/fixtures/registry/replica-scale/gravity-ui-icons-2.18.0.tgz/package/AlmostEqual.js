"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const AlmostEqual = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("path", { fill: "currentColor", d: "M1.747 10.287c1.315-1.185 2.78-1.35 4.016-1.143 1.205.202 2.22.76 2.73 1.045.596.332 1.343.721 2.174.842.794.116 1.682-.01 2.608-.768a.75.75 0 0 1 .95 1.161c-1.286 1.052-2.61 1.261-3.774 1.092-1.127-.165-2.086-.68-2.689-1.017-.502-.28-1.32-.72-2.248-.875-.897-.15-1.865-.032-2.762.777a.75.75 0 0 1-1.005-1.114m0-5.66c1.315-1.185 2.78-1.349 4.016-1.142 1.205.202 2.22.76 2.73 1.045.596.332 1.343.72 2.174.842.794.115 1.682-.01 2.608-.768a.75.75 0 0 1 .95 1.161c-1.286 1.052-2.61 1.261-3.774 1.091-1.127-.164-2.086-.68-2.689-1.016-.502-.28-1.32-.72-2.248-.875-.897-.15-1.865-.032-2.762.777a.75.75 0 0 1-1.005-1.115" })));
exports.default = AlmostEqual;
