"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const ArrowUpLeft = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("path", { fill: "currentColor", d: "M3.27 2.521a.75.75 0 0 0-.748.75v5.657a.751.751 0 0 0 1.5 0V5.083l8.175 8.176a.75.75 0 0 0 1.06-1.06L5.083 4.02H8.93a.75.75 0 0 0-.001-1.5z" })));
exports.default = ArrowUpLeft;
