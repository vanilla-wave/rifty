"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const BellFill = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("path", { fill: "currentColor", d: "M9.955 13.416a2 2 0 0 1-3.911 0c1.3.141 2.611.141 3.911 0M8 1a4.27 4.27 0 0 1 4.187 3.432l.619 3.096c.127.634.438 1.216.895 1.673l.436.436a1.24 1.24 0 0 1-.598 2.085l-1.462.338a18.1 18.1 0 0 1-8.154 0l-1.462-.338a1.24 1.24 0 0 1-.598-2.085L2.3 9.2a3.27 3.27 0 0 0 .895-1.673l.62-3.096A4.27 4.27 0 0 1 8 1" })));
exports.default = BellFill;
