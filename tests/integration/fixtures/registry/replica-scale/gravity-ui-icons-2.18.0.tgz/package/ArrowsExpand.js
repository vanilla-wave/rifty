"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const ArrowsExpand = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("path", { fill: "currentColor", d: "M7.526 1.168a.75.75 0 0 1 1.004.052l1.75 1.75.052.056a.75.75 0 0 1-1.056 1.056L9.22 4.03l-.47-.47v3.69h3.69l-.47-.47a.75.75 0 0 1 1.06-1.06l1.75 1.75.052.056a.75.75 0 0 1-.052 1.004l-1.75 1.75-.056.052a.75.75 0 0 1-1.056-1.056l.052-.056.47-.47H8.75v3.69l.47-.47a.75.75 0 1 1 1.06 1.06l-1.75 1.75-.056.052a.75.75 0 0 1-1.004-.052l-1.75-1.75-.052-.056a.75.75 0 0 1 1.056-1.056l.056.052.47.47V8.75H3.56l.47.47a.75.75 0 1 1-1.06 1.06L1.22 8.53l-.052-.056A.75.75 0 0 1 1.22 7.47l1.75-1.75.056-.052a.75.75 0 0 1 1.056 1.056l-.052.056-.47.47h3.69V3.56l-.47.47a.75.75 0 1 1-1.06-1.06l1.75-1.75z" })));
exports.default = ArrowsExpand;
