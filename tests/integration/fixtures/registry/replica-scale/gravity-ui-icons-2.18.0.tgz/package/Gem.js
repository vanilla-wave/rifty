"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const Gem = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("g", { fill: "currentColor" },
        React.createElement("path", { d: "M12.234 2.014A2 2 0 0 1 13.6 2.8l1.42 1.892a2 2 0 0 1-.105 2.53l-5.42 6.096-.155.158a2 2 0 0 1-2.678 0l-.156-.158-5.42-6.096a2 2 0 0 1-.105-2.53L2.4 2.8A2 2 0 0 1 4 2h8zM8 11.094 9.862 6.75H6.138zm-1.79-.364L4.506 6.75H2.674zm3.578-.003 3.537-3.977h-1.832zM3.999 3.5a.5.5 0 0 0-.4.2L2.437 5.25H4.46l.584-1.75zm7.542 1.75h2.021L12.4 3.7a.5.5 0 0 0-.4-.2h-1.042zm-5.5 0H9.96L9.377 3.5H6.624z" }),
        React.createElement("path", { fillRule: "evenodd", d: "M12.235 2.014A2 2 0 0 1 13.6 2.8l1.42 1.892c.57.761.526 1.819-.106 2.53l-5.419 6.096-.156.158a2 2 0 0 1-2.678 0l-.156-.158-5.419-6.096a2 2 0 0 1-.105-2.53L2.4 2.8A2 2 0 0 1 4 2h8zm-4.236 9.082L9.862 6.75H6.138zm-1.788-.366L4.506 6.75H2.674zm3.576 0 3.54-3.98h-1.833zM4 3.5a.5.5 0 0 0-.4.2L2.438 5.25h2.021l.584-1.75zm7.541 1.75h2.022L12.4 3.7a.5.5 0 0 0-.4-.2h-1.043zm-5.5 0h3.918L9.376 3.5H6.623z", clipRule: "evenodd" }))));
exports.default = Gem;
