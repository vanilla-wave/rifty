"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const CircleLetterC = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("path", { fill: "currentColor", fillRule: "evenodd", d: "M13.5 8a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0M15 8A7 7 0 1 1 1 8a7 7 0 0 1 14 0M6.458 8c0-.8.2-1.289.445-1.569C7.136 6.165 7.487 6 8 6c.368 0 .648.086.857.222.205.134.384.345.51.672a.75.75 0 0 0 1.4-.538c-.226-.59-.593-1.066-1.09-1.39C9.181 4.643 8.604 4.5 8 4.5c-.862 0-1.657.293-2.226.944-.557.637-.816 1.523-.816 2.556s.259 1.92.816 2.556c.569.65 1.364.944 2.226.944.605 0 1.182-.143 1.676-.466.498-.324.865-.8 1.092-1.39a.75.75 0 0 0-1.4-.538c-.127.327-.306.538-.511.672-.209.136-.49.222-.857.222-.513 0-.864-.165-1.097-.431-.245-.28-.445-.77-.445-1.569", clipRule: "evenodd" })));
exports.default = CircleLetterC;
