"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const CalendarXmark = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("g", { fill: "currentColor" },
        React.createElement("path", { d: "M9.151 6.47a.751.751 0 0 1 1.062 1.06L9.15 8.59l1.06 1.061a.751.751 0 0 1-1.06 1.062L8.091 9.65l-1.06 1.062A.75.75 0 0 1 5.97 9.65l1.06-1.06-1.06-1.06a.75.75 0 0 1 1.06-1.06l1.06 1.06z" }),
        React.createElement("path", { fillRule: "evenodd", d: "M11 .95a.75.75 0 0 1 .75.75v.687a3 3 0 0 1 2.75 2.987v6l-.004.154a3 3 0 0 1-2.842 2.842l-.154.004h-7a3 3 0 0 1-2.996-2.846l-.004-.154v-6a3 3 0 0 1 2.75-2.99V1.7a.75.75 0 0 1 1.5 0v.674h4.5V1.7A.75.75 0 0 1 11 .95M5.75 4.476a.75.75 0 0 1-1.5 0v-.58A1.5 1.5 0 0 0 3 5.373v6a1.5 1.5 0 0 0 1.5 1.5h7a1.5 1.5 0 0 0 1.5-1.5v-6a1.5 1.5 0 0 0-1.25-1.479v.581a.75.75 0 0 1-1.5 0v-.602h-4.5z", clipRule: "evenodd" }))));
exports.default = CalendarXmark;
