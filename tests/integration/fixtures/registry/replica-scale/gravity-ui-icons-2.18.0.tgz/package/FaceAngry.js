"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const FaceAngry = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("path", { fill: "currentColor", fillRule: "evenodd", d: "M13.5 8a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0M15 8A7 7 0 1 1 1 8a7 7 0 0 1 14 0m-6 3.5A.75.75 0 0 0 9 10H7a.75.75 0 0 0 0 1.5zm1.5-2a.75.75 0 0 1-.75-.75V7.71l-.068.018a.75.75 0 0 1-.364-1.456l2-.5a.75.75 0 0 1 .364 1.456l-.432.108V8.75a.75.75 0 0 1-.75.75m-5 0a.75.75 0 0 1-.75-.75V7.336l-.432-.108a.75.75 0 0 1 .364-1.456l2 .5a.75.75 0 0 1-.364 1.456L6.25 7.71v1.04a.75.75 0 0 1-.75.75", clipRule: "evenodd" })));
exports.default = FaceAngry;
