"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const CrownDiamond = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("g", { fill: "currentColor", fillRule: "evenodd", clipRule: "evenodd" },
        React.createElement("path", { d: "m8.427 11.073 1.205-1.205a.4.4 0 0 0 .118-.285.8.8 0 0 0-.236-.569L8.427 7.927a.603.603 0 0 0-.854 0L6.486 9.014a.8.8 0 0 0-.236.57c0 .106.042.208.118.284l1.205 1.205a.604.604 0 0 0 .854 0" }),
        React.createElement("path", { d: "M16 5.796v-.028a1.768 1.768 0 0 0-3.018-1.25l-.76.76-.024.024-.374.374-.415.415a.335.335 0 0 1-.561-.149l-.155-.566-.139-.51-.009-.033-.65-2.386a1.964 1.964 0 0 0-3.79 0l-.65 2.386-.01.032-.139.511-.154.566a.335.335 0 0 1-.56.15l-.416-.416-.374-.374-.024-.024-.76-.76A1.768 1.768 0 0 0 0 5.768v.028q0 .203.046.403l1.3 5.631a1.4 1.4 0 0 0 .778.958 14.02 14.02 0 0 0 11.752 0c.394-.182.681-.535.779-.958l1.299-5.63q.045-.2.046-.404M3.53 7.152c.997.997 2.698.545 3.07-.815l.952-3.495a.464.464 0 0 1 .896 0L9.4 6.337c.37 1.36 2.072 1.812 3.068.815l1.574-1.574a.268.268 0 0 1 .457.19v.028a.3.3 0 0 1-.008.066l-1.288 5.584a12.52 12.52 0 0 1-10.408 0L1.508 5.862a.3.3 0 0 1-.008-.066v-.028a.268.268 0 0 1 .457-.19z" }))));
exports.default = CrownDiamond;
