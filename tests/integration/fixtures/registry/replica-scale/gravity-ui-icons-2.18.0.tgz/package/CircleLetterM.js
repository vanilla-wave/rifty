"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const CircleLetterM = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("path", { fill: "currentColor", fillRule: "evenodd", d: "M13.5 8a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0M15 8A7 7 0 1 1 1 8a7 7 0 0 1 14 0m-4-2.084a.916.916 0 0 0-1.656-.539L8 7.225 6.656 5.377A.916.916 0 0 0 5 5.916v4.334a.75.75 0 0 0 1.5 0V7.713l.893 1.228a.75.75 0 0 0 1.214 0L9.5 7.713v2.537a.75.75 0 0 0 1.5 0z", clipRule: "evenodd" })));
exports.default = CircleLetterM;
