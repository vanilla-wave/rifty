"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const AlarmFill = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 17, height: 17, fill: "none", viewBox: "0 0 17 17" }, props),
    React.createElement("g", { fill: "currentColor" },
        React.createElement("path", { fillRule: "evenodd", d: "M8.5 1.063a6.905 6.905 0 0 1 5.153 11.499l1.376 1.833a.797.797 0 0 1-1.274.957l-1.297-1.729a6.87 6.87 0 0 1-3.958 1.25 6.87 6.87 0 0 1-3.915-1.218l-1.313 1.719a.796.796 0 1 1-1.265-.967l1.375-1.803A6.906 6.906 0 0 1 8.5 1.063m0 3.445a.797.797 0 0 0-.798.797v3.187c0 .25.119.487.319.637l1.417 1.062a.797.797 0 1 0 .956-1.274l-1.098-.823v-2.79a.797.797 0 0 0-.797-.796", clipRule: "evenodd" }),
        React.createElement("path", { d: "M2.624.5a.797.797 0 1 1 1.127 1.126L1.626 3.75A.797.797 0 0 1 .499 2.624zm10.624 0a.797.797 0 0 1 1.127 0l2.124 2.124a.797.797 0 0 1-1.126 1.127l-2.125-2.125a.797.797 0 0 1 0-1.127" }))));
exports.default = AlarmFill;
