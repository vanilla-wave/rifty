"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const LayoutHeaderCellsLargeLetterD = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("path", { fill: "currentColor", fillRule: "evenodd", d: "M4 3.5h8A1.5 1.5 0 0 1 13.5 5v.5h-11V5A1.5 1.5 0 0 1 4 3.5m-1.5 7v.5A1.5 1.5 0 0 0 4 12.5h3.25v-2zm0-1.5h4.75V7H2.5zm6.25 1.5V14H4a3 3 0 0 1-3-3V5a3 3 0 0 1 3-3h8a3 3 0 0 1 3 3v2H8.75zm3.67-1.995a3.25 3.25 0 0 1 0 6.5h-1.17a.75.75 0 0 1-.75-.75v-5a.75.75 0 0 1 .75-.75zm0 5a1.75 1.75 0 1 0 0-3.5H12v3.5z", clipRule: "evenodd" })));
exports.default = LayoutHeaderCellsLargeLetterD;
