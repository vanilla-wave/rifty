"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const CirclesConcentric = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("path", { fill: "currentColor", fillRule: "evenodd", d: "M2.5 8a5.5 5.5 0 0 1 8.14-4.827.75.75 0 1 0 .72-1.315 7 7 0 0 0-9.502 9.502.75.75 0 0 0 1.315-.72A5.5 5.5 0 0 1 2.5 8m11.642-3.36a.75.75 0 1 0-1.315.72 5.5 5.5 0 0 1-7.466 7.466.75.75 0 1 0-.722 1.316 7 7 0 0 0 9.502-9.502M9.5 8a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0M11 8a3 3 0 1 1-6 0 3 3 0 0 1 6 0", clipRule: "evenodd" })));
exports.default = CirclesConcentric;
