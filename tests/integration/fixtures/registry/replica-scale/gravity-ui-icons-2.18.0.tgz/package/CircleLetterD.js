"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const CircleLetterD = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("path", { fill: "currentColor", fillRule: "evenodd", d: "M13.5 8a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0M15 8A7 7 0 1 1 1 8a7 7 0 0 1 14 0M6.55 4.75a.75.75 0 0 0-.75.75v5c0 .414.336.75.75.75h1.5a3.25 3.25 0 1 0 0-6.5zm1.5 5H7.3v-3.5h.75a1.75 1.75 0 1 1 0 3.5", clipRule: "evenodd" })));
exports.default = CircleLetterD;
