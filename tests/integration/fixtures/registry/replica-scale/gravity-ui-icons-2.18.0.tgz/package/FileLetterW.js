"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const FileLetterW = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("path", { fill: "currentColor", fillRule: "evenodd", d: "M12.5 12a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 12V4A1.5 1.5 0 0 1 5 2.5h2.757a1.5 1.5 0 0 1 1.061.44l3.243 3.242a1.5 1.5 0 0 1 .439 1.06zm.621-6.879A3 3 0 0 1 14 7.243V12a3 3 0 0 1-3 3H5a3 3 0 0 1-3-3V4a3 3 0 0 1 3-3h2.757a3 3 0 0 1 2.122.879zM5.702 6.987a.75.75 0 0 0-1.404.526l1.5 4a.75.75 0 0 0 1.404 0L8 9.386l.798 2.127a.75.75 0 0 0 1.418-.039l1.253-4a.75.75 0 0 0-1.431-.448l-.602 1.919-.734-1.958a.75.75 0 0 0-1.404 0L6.5 9.114z", clipRule: "evenodd" })));
exports.default = FileLetterW;
