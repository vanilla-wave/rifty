"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const BackwardStepFill = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("path", { fill: "currentColor", d: "M2.316 2.073A.75.75 0 0 1 3 2.82v10.494a.75.75 0 0 1-1.5 0V2.82a.75.75 0 0 1 .816-.747m9.54.193c1.164-.76 2.706.076 2.706 1.465v8.478c0 1.39-1.542 2.225-2.706 1.466l-6.498-4.24a1.75 1.75 0 0 1 0-2.93z" })));
exports.default = BackwardStepFill;
