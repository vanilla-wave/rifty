"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const ChartLinePoints = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("g", { clipPath: "url(#a)" },
        React.createElement("path", { fill: "currentColor", d: "M14.75 12.5a.75.75 0 0 1 0 1.5H1.25a.75.75 0 0 1 0-1.5zm-.05-9.511a.751.751 0 0 1 1.1 1.022l-3.027 3.258a2.25 2.25 0 1 1-4.273.98l.001-.035-1.691-.846a2.24 2.24 0 0 1-2.831.238l-2.149 2.62a.75.75 0 0 1-1.16-.952L3.03 6.4l.051-.057A2.25 2.25 0 1 1 7.5 5.75q-.001.14-.02.276l1.55.775a2.245 2.245 0 0 1 2.674-.586zm-3.95 4.51a.75.75 0 1 0 0 1.501.75.75 0 0 0 0-1.5M5.25 5a.75.75 0 1 0 0 1.501.75.75 0 0 0 0-1.5" })),
    React.createElement("defs", null,
        React.createElement("clipPath", { id: "a" },
            React.createElement("path", { fill: "currentColor", d: "M0 0h16v16H0z" })))));
exports.default = ChartLinePoints;
