"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const BroomMotionFill = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("path", { fill: "currentColor", d: "M10.537.745a.75.75 0 0 1 .921.527l1.295 4.739c1.43.496 2.454 1.895 2.225 3.513-.238 1.674-.607 2.955-.922 3.825-.157.434-.3.767-.407.995a7 7 0 0 1-.13.264l-.038.072-.013.02-.006.012a.75.75 0 0 1-.764.368l-1.086-.166a.5.5 0 0 1-.38-.56l.319-2.078a.34.34 0 0 0-.633-.212l-1.04 1.918a1 1 0 0 1-.978.516l-4.91-.752c-.866-.133-1.087-1.236-.43-1.73l.31-.24c.795-.642 2.067-1.843 2.912-3.488.773-1.504 2.401-2.868 4.332-2.587L10.01 1.666a.75.75 0 0 1 .526-.92M3.375 8a.75.75 0 1 1 0 1.5.75.75 0 0 1 0-1.5M2.25 5a.75.75 0 1 1 0 1.5.75.75 0 0 1 0-1.5m3.64-2a.75.75 0 1 1 0 1.5.75.75 0 0 1 0-1.5" })));
exports.default = BroomMotionFill;
