"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const Cup = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("g", { clipPath: "url(#a)" },
        React.createElement("path", { fill: "currentColor", fillRule: "evenodd", d: "M10.522 5.835c.838-.402.978-.795.978-1.085 0-.272-.123-.634-.83-1.01l-.149-.075C9.667 3.255 8.352 3 6.75 3s-2.916.256-3.772.665C2.14 4.067 2 4.46 2 4.75s.14.683.978 1.085c.856.41 2.171.665 3.772.665s2.916-.256 3.771-.665M6.75 8c1.882 0 3.57-.322 4.715-.966-.059 1.35-.216 2.595-.634 3.616-.303.74-.72 1.293-1.296 1.674-.579.383-1.444.676-2.785.676-1.34 0-2.206-.293-2.785-.676-.575-.381-.992-.934-1.296-1.674-.418-1.021-.575-2.267-.634-3.616C3.18 7.678 4.868 8 6.75 8m6.246-3.388C12.88 2.537 10.128 1.5 6.75 1.5 3.298 1.5.5 2.583.5 4.75.5 9 .5 14.5 6.75 14.5c3.36 0 4.913-1.589 5.632-3.719q.419-.13.818-.293c.615-.256 1.268-.613 1.79-1.112C15.524 8.865 16 8.12 16 7.158c0-.437-.097-.89-.345-1.304a2.4 2.4 0 0 0-.956-.89c-.563-.293-1.187-.358-1.703-.352m-.003 1.5c-.015.97-.06 1.967-.203 2.92.963-.432 1.71-1.056 1.71-1.874 0-.808-.656-1.059-1.507-1.046", clipRule: "evenodd" })),
    React.createElement("defs", null,
        React.createElement("clipPath", { id: "a" },
            React.createElement("path", { fill: "currentColor", d: "M0 0h16v16H0z" })))));
exports.default = Cup;
