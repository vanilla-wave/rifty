"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const Circles4Square = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("path", { fill: "currentColor", fillRule: "evenodd", d: "M3.047 7.125A3 3 0 1 0 4.5 1.5a3 3 0 0 0-1.453 5.625M4.5 6a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3m5.547 1.125A3 3 0 1 0 11.5 1.5a3 3 0 0 0-1.453 5.625M11.5 6a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3m-7 8.5a3 3 0 1 1 0-6 3 3 0 0 1 0 6m1.5-3a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0m4.047 2.625A3 3 0 1 0 11.5 8.5a3 3 0 0 0-1.453 5.625M11.5 13a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3", clipRule: "evenodd" })));
exports.default = Circles4Square;
