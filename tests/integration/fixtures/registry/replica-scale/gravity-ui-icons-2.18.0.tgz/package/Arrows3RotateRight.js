"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const Arrows3RotateRight = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("g", { clipPath: "url(#a)" },
        React.createElement("path", { fill: "currentColor", fillRule: "evenodd", d: "M4.61 2.503a6.47 6.47 0 0 1 3.383-.984 6.48 6.48 0 0 1 4.515 1.77l-.004-.559a.75.75 0 1 1 1.5-.013l.021 2.5a.75.75 0 0 1-.743.756l-2.497.022a.75.75 0 1 1-.013-1.5l.817-.007a4.98 4.98 0 0 0-3.583-1.469 4.97 4.97 0 0 0-2.602.756.75.75 0 0 1-.795-1.272m9.097 8.716a6.5 6.5 0 0 0 .84-3.422.75.75 0 1 0-1.5.053 4.97 4.97 0 0 1-.646 2.63 4.98 4.98 0 0 1-3.064 2.37l.403-.712a.75.75 0 0 0-1.306-.738l-1.229 2.173a.75.75 0 0 0 .283 1.022l2.176 1.23a.75.75 0 1 0 .739-1.305l-.487-.275a6.48 6.48 0 0 0 3.79-3.026m-11.258.099a6.47 6.47 0 0 0 2.544 2.438.75.75 0 0 0 .704-1.325 4.97 4.97 0 0 1-1.955-1.875 4.98 4.98 0 0 1-.52-3.838l.415.705a.75.75 0 1 0 1.292-.762L3.66 4.511a.75.75 0 0 0-1.027-.266L.481 5.513a.75.75 0 1 0 .761 1.293l.483-.284a6.48 6.48 0 0 0 .724 4.796", clipRule: "evenodd" })),
    React.createElement("defs", null,
        React.createElement("clipPath", { id: "a" },
            React.createElement("path", { fill: "currentColor", d: "M0 0h16v16H0z" })))));
exports.default = Arrows3RotateRight;
