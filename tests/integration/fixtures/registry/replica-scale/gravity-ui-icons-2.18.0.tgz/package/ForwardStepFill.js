"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const ForwardStepFill = (props) => (React.createElement("svg", Object.assign({ xmlns: "http://www.w3.org/2000/svg", width: 16, height: 16, fill: "none", viewBox: "0 0 16 16" }, props),
    React.createElement("path", { fill: "currentColor", d: "M13.684 2.073a.75.75 0 0 1 .816.747v10.494a.75.75 0 0 1-1.5 0V2.82a.75.75 0 0 1 .684-.747M1.5 3.762c0-1.39 1.542-2.226 2.706-1.466l6.497 4.238a1.75 1.75 0 0 1 0 2.932l-6.497 4.239c-1.164.76-2.706-.076-2.706-1.466z" })));
exports.default = ForwardStepFill;
